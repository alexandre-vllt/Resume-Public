Xr = [269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,269,268,268,268,267,267,267,267,267,267,266,255,249
];
Yr = [103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103,103
];
Xy = [213,213,213,213,213,213,213,213,213,213,213,213,213,213,213,187,145,167,199,229,261,319,347,376,401,454,479,504,528,574,598,621,644,691,714,720,701,662,644,626,610,577,561,547,533,507,494,481,468,443,430,417,405,379,367,354,341,316,304,291,278,254,241,228,216,191,179,167,154,129,130,140,150,168,175,183,190,204,211,218,225,238,245,252,259,273,279,286,293,307,313,320,327,339,346,353,359,372,379,386,392,405,412,418,425,437,444,450,457,469,476,482,488,501,507,513,519,532,538,544,550,562,568,574,580,593,598,604,610,622,628,634,640,652,657,663,669,680,686,692,697,709,715,720,725,718,714,711,708,702,699,696,693,686,683,680,677,671,668,665,662,656,653,651,648,642,639,637,634,628,626,623,620,615,612,609,607,602,599,596,594,589,586,584,581,576,574,572,569,564,562,559,557,553,550,548,546,541,539,536,535,530,528,526,524,519,517,515,513,509,507,505,503,499,497,495,493,489,488,486,484,480,478,477,475,471,470,468,466,463,461,459,458,454,453,451,450,447,445,444,442,439,438,436,435,432,431,429,428,425,424,423,421,419,417,416,415,412,411,410,409,407,405,405,404,401,400,399,398,396,395,394,393,393,393
];
Yy = [205,205,205,205,205,205,205,205,205,205,205,205,205,205,205,201,199,198,200,200,200,200,201,201,201,203,203,203,203,204,205,205,204,205,206,206,206,207,207,208,209,211,211,212,212,213,213,214,215,216,216,217,217,219,219,219,220,221,221,222,222,223,224,224,225,226,226,227,227,228,228,228,228,229,229,229,229,229,230,230,230,230,230,230,231,231,231,231,231,232,231,232,232,232,233,233,233,233,233,234,234,234,234,234,235,235,235,235,235,235,235,235,235,236,237,237,237,237,237,238,238,238,238,238,238,239,239,239,240,240,240,240,240,241,241,241,241,242,242,242,243,243,243,243,243,244,244,244,244,244,244,244,244,244,244,244,244,244,245,245,245,245,245,245,245,245,245,245,245,245,245,245,245,245,245,244,245,244,244,244,244,244,244,244,244,244,244,244,244,244,244,244,244,244,244,244,244,243,243,243,243,243,243,243,243,243,243,242,242,242,243,243,243,242,242,242,242,242,242,241,241,241,241,241,241,241,241,241,241,241,241,240,240,240,240,239,239,239,239,239,239,239,239,239,239,239,239,239,239,239,239,239,239,239,239,239,239,237,237,237,238,237,237,237,237,237,237,237,236,236,236,236,236,236,236
];
Xw = [490,490,490,490,490,490,490,490,490,490,480,431,382,288,243,226,223,215,210,205,199,186,179,172,164,150,142,135,128,146,154,162,170,184,190,196,202,213,219,224,230,241,247,253,258,269,275,280,286,297,302,308,314,324,330,336,342,355,362,369,376,389,396,403,409,423,429,436,442,456,462,469,475,488,495,501,508,521,527,533,540,553,559,565,571,584,590,597,603,615,622,628,634,646,653,658,665,677,683,689,695,707,713,719,725,721,717,713,710,704,700,697,694,688,685,681,678,671,668,665,662,655,652,649,646,639,636,633,630,624,620,617,614,608,605,602,599,593,590,587,584,579,576,573,570,564,561,559,556,550,547,545,542,537,534,531,528,523,520,518,515,510,507,504,502,497,494,492,489,484,482,479,477,472,470,467,465,460,458,455,453,448,446,444,442,437,435,433,430,426,424,421,419,415,413,411,409,405,403,401,399,395,393,391,389,385,383,381,379,375,373,371,369,366,364,362,360,357,355,353,352,348,346,345,343,340,338,337,335,332,330,329,327,324,323,321,320,317,316,314,313,310,309,307,306,303,302,300,299,296,295,294,293,291,290,289,288,287,286,285,284,282,282,281,281,280,280,279,279,278,278,278,277,277,277
];
Yw = [135,135,135,135,135,135,135,135,135,135,139,152,165,191,203,217,231,258,271,283,296,319,330,342,353,375,386,394,385,362,351,340,331,312,303,295,287,272,264,256,248,233,225,217,210,194,187,179,171,156,149,141,133,118,111,104,103,114,119,123,128,136,140,144,148,156,160,164,168,176,180,184,188,196,200,204,208,216,220,224,228,235,239,243,247,254,258,262,266,273,277,281,285,292,296,299,303,311,314,318,321,329,333,336,340,348,352,357,361,370,374,378,382,390,392,389,386,381,379,377,375,370,367,365,363,358,356,354,351,347,345,343,340,335,333,331,329,325,322,320,318,314,312,309,307,304,302,299,297,293,291,289,287,283,281,279,277,273,271,269,267,263,261,259,258,254,252,250,248,244,242,240,239,235,233,231,230,226,224,223,221,217,216,214,212,209,207,205,204,200,199,197,195,192,190,189,187,184,182,181,179,176,175,173,172,169,167,166,165,162,160,159,157,154,153,152,151,148,147,145,144,142,140,139,138,135,134,133,131,129,128,126,125,123,122,120,119,117,116,115,114,112,111,110,108,106,105,105,104,103,103,103,103,103,103,104,104,105,105,106,106,107,108,108,109,110,111,111,111,112,113,113,114,114,114
];

Yr = 480-Yr;
Yy = 480-Yy;
Yw = 480-Yw;

[Xmin, Xmax,Ymin,Ymax] = GetFrame(Xr,Yr,Xy,Yy,Xw,Yw);

[Xr, Yr] = RemoveOutlier(Xr,Yr);
[Xy, Yy] = RemoveOutlier(Xy,Yy);
[Xw, Yw] = RemoveOutlier(Xw,Yw);

% on verifie le cas : si il manque des balles sur toutes la sequences cad qu'il a une tableau de cpoordonnées composé uniquement de NaN, alors on transforme le tableau en tableau de 0 et nous n'appelons pas interpolate Nan.
if isnan(Xr)
    Xr = 0*ones(1,length(Xr));
    Yr = 0*ones(1,length(Yr));
elseif isnan(Yr)
    Yr = 0*ones(1,length(Yr));
    Xr = 0*ones(1,length(Xr));
else
    [Xr, Yr] = InterpolateNan(Xr,Yr);
end

if isnan(Xy)
    Xy = 0*ones(1,length(Xy));
    Yy = 0*ones(1,length(Yy));
elseif isnan(Yy)
    Yy = 0*ones(1,length(Yy));
    Xy = 0*ones(1,length(Xy));
else
    [Xy, Yy] = InterpolateNan(Xy,Yy);
end

if isnan(Xw)
    Xw = 0*ones(1,length(Xw));
    Yw = 0*ones(1,length(Yw));
elseif isnan(Yw)
    Yw = 0*ones(1,length(Yw));
    Xw = 0*ones(1,length(Xw));
else
    [Xw, Yw] = InterpolateNan(Xw,Yw);
end

Ly = GetBallPathLength(Xy, Yy);
Lr = GetBallPathLength(Xr, Yr);
Lw = GetBallPathLength(Xw, Yw);

MoveDistPx = 9;
[idx, MoveDist] = GetFirstMoveIdx(Xr,Yr, MoveDistPx);

[FirstBall,SecondBall,LastBall, NbBallsMoved] = GetBallMoveOrder(Xr, Yr, Xy, Yy, Xw, Yw, MoveDistPx);

BallBorderDist = 9;
% utilise des conditions pour pas imprimer les coordonnées si la boule n'est pas la donc que sa coordonnées en X soit egale a 0
hold on
if Xr(1) ~= 0 
    plot(Xr(1), Yr(1), "k-hexagram","MarkerEdgeColor","r", 'MarkerSize',15)
    plot(Xr, Yr, "r:*")
end
if Xy(1) ~= 0 
    plot(Xy(1), Yy(1), "k-hexagram","MarkerEdgeColor",[0.9290 0.6940 0.1250], 'MarkerSize',15)
    plot(Xy, Yy,":*", "MarkerEdgeColor", [0.9290 0.6940 0.1250])
end
if Xw(1) ~= 0 
    plot(Xw(1), Yw(1), "k-hexagram","MarkerEdgeColor","b", 'MarkerSize',15)
    plot(Xw, Yw, "b:*")
end


rectangle('position', [Xmin, Ymin, Xmax - Xmin, Ymax - Ymin]);


date = string(datetime);
a = sprintf("Scores sheet - T1 – (%s)", date);
title(a)


ind1r = GetFirstMoveIdx(Xr,Yr, MoveDistPx);
ind1w = GetFirstMoveIdx(Xw,Yw, MoveDistPx);
ind1y = GetFirstMoveIdx(Xy,Yy, MoveDistPx);

if FirstBall == 1 
    IdxTouch = GetTouchIdx(Xr,Yr,Xmin, Xmax, Ymin, Ymax, BallBorderDist);
    Ball = 'red';
    nbrebond = length(find(max(ind1w,ind1y) >= IdxTouch & IdxTouch >= min(ind1y, ind1w)));
end
if FirstBall == 2 
    IdxTouch = GetTouchIdx(Xy,Yy,Xmin, Xmax, Ymin, Ymax, BallBorderDist);
    Ball = 'yellow';
    nbrebond = length(find(max(ind1w,ind1r) >= IdxTouch & IdxTouch >= min(ind1r, ind1w)));
end
if FirstBall == 3
    IdxTouch = GetTouchIdx(Xw,Yw,Xmin, Xmax, Ymin, Ymax, BallBorderDist);
    Ball = 'white';
    nbrebond = length(find(max(ind1r,ind1y) >= IdxTouch & IdxTouch >= min(ind1y, ind1r)));
end
bandtouched = length(IdxTouch);

distr = GetBallPathLength(Xr,Yr);
distw = GetBallPathLength(Xw,Yw);
disty = GetBallPathLength(Xy,Yy);

color_win = [0.392157 1.000000 0.000000];
color_loose = [1.000000 0.000000 0.000000];
%% resulat de la partie 
if nbrebond >= 3 && NbBallsMoved == 3 
    result = 'Win';

    if FirstBall == 1  
        plot(Xr(IdxTouch(max(ind1w,ind1y) >= IdxTouch & IdxTouch >= min(ind1y, ind1w))), Yr(IdxTouch(max(ind1w,ind1y) >= IdxTouch & IdxTouch >= min(ind1y, ind1w))), "o","MarkerEdgeColor",color_win, 'MarkerSize', 15, 'Linewidth', 2)
    end
    if FirstBall == 2  
        plot(Xy(IdxTouch(max(ind1w,ind1r) >= IdxTouch & IdxTouch >= min(ind1r, ind1w))), Yy(IdxTouch(max(ind1w,ind1r) >= IdxTouch & IdxTouch >= min(ind1r, ind1w))), "o","MarkerEdgeColor",color_win, 'MarkerSize', 15, 'Linewidth', 2)
    end
    if FirstBall == 3
        plot(Xw(IdxTouch(max(ind1r,ind1y) >= IdxTouch & IdxTouch >= min(ind1y, ind1r))), Yw(IdxTouch(max(ind1r,ind1y) >= IdxTouch & IdxTouch >= min(ind1y, ind1r))), "o","MarkerEdgeColor",color_win, 'MarkerSize', 15, 'Linewidth', 2)
    end

else 
    result = 'Loose';

    if FirstBall == 1  
        plot(Xr(IdxTouch), Yr(IdxTouch), "o","MarkerEdgeColor",color_loose, 'MarkerSize', 15,  'Linewidth', 2)
    end
    if FirstBall == 2  
        plot(Xy(IdxTouch), Yy(IdxTouch), "o","MarkerEdgeColor",color_loose, 'MarkerSize', 15,  'Linewidth', 2)
    end
    if FirstBall == 3
        plot(Xw(IdxTouch), Yw(IdxTouch), "o","MarkerEdgeColor",color_loose, 'MarkerSize', 15,  'Linewidth', 2)
    end
end

%legende 
% legend('hahahahha', 'location' , 'southeastoutside')
text(Xmin+20 , Ymin-10, sprintf('Score sheet for "%s"', Ball))
text(Xmin+20 , Ymin-20, sprintf('---"%s"---', result))
text(Xmin+420 , Ymin-20, sprintf('%d band(s) touched', bandtouched))
text(Xmin+420 , Ymin-10, sprintf('%d ball(s) moved', NbBallsMoved))
text(Xmin+20 , Ymin-30, sprintf('red : %.0fpx', round(distr)))
text(Xmin+220 , Ymin-30, sprintf('yellow : %.0f px', round(disty)))
text(Xmin+420 , Ymin-30, sprintf('white : %.0f px', round(distw)))

 
axis off

saveas(gcf,'ScoreSheetT1.pdf','pdf')

hold off
% fonction qui calcule la distance parcouru par une balle 
% En utilisant pythagore (operation sur des vecteurs) on determine la distance entre deux coordonnées à l'aide de la fonction diff(X)  succésive puis on additionne ces longueurs grasse a la fct sum.
 
function PathLength = GetBallPathLength(X,Y)

length_vector = sqrt(diff(X).^2 + diff(Y).^2);
PathLength = sum(length_vector);

end

% fonction qui trouve les bords du billard
% On cherche les coordonnées maximales et minimales des balles pour
% determiner les bords du billard

function [Xmin, Xmax,Ymin,Ymax] = GetFrame(Xr,Yr,Xy,Yy,Xw,Yw)

Xmax = max([max(Xr) max(Xy) max(Xw)]);
Xmin = min([min(Xr) min(Xy) min(Xw)]);
Ymax = max([max(Yr) max(Yy) max(Yw)]);
Ymin = min([min(Yr) min(Yy) min(Yw)]);

end

%fonction qui determine si une boule a bougé pendant la partie et si oui à quel indice.
% On regarde si la distance entre sa première coordonnées et les autres est supérieurs à MoveDistPx ( condition si elle a bougé ). Si la boule a bougé on note l'indice de son premier mouvement dans FirstMoveIdx et la distance dans MoveDist.
% En revanche si elle n'a pas bougé on met FirstMoveIdx au dernier indice + 1. de maniere a ce que cet indice corresponde a un indice impossible. MoveDist sera alors definit a 0.
% De plus nous avons etudiez le cas a savoir si il manque une boule et donc que les opérations sur les vecteurs ne sont pas possibles.
function [FirstMoveIdx, MoveDist] = GetFirstMoveIdx(X,Y, MoveDistPx)
X1 = X(1);
Y1 = Y(1);
X = X - X1;
Y = Y - Y1;

if X1 == 0 && Y1 == 0
    d = 0;
else
    d = sqrt( X.^2 + Y.^2 );
end
if d <= MoveDistPx 
    FirstMoveIdx = length(X)+1;
    MoveDist = 0;
else
    FirstMoveIdx = find(d>MoveDistPx, 1);
    MoveDist = sqrt(X(FirstMoveIdx).^2 + Y(FirstMoveIdx).^2);
end

end

% cette fonction permet de récupérer tout les indices coorespondant a un rebond bord-boules.
% on s'épare les cas pour chaque bords de maniere a ce que si une boule touche deux bords d'affiler, sela est compter comme deux rebonds
% on cherche a lors les indices de X Y t.q la distance considerer entre les bords (calculer dans getFrame) et la boule soit inferieur ou egale a BallBorderDist.

function [IdxTouch]=GetTouchIdx(X,Y,Xmin, Xmax, Ymin, Ymax, BallBorderDist)

IdxTouch_Xmax = find( (X+BallBorderDist) >= Xmax);
b = [0, diff(IdxTouch_Xmax)];
IdxTouch_Xmax = IdxTouch_Xmax((b ~= 1).*IdxTouch_Xmax > 1);

IdxTouch_Xmin = find( (X-BallBorderDist) <= Xmin);
b = [0, diff(IdxTouch_Xmin)];
IdxTouch_Xmin = IdxTouch_Xmin((b ~= 1).*IdxTouch_Xmin > 1);

IdxTouch_Ymax = find( (Y+BallBorderDist) >= Ymax);
b = [0, diff(IdxTouch_Ymax)];
IdxTouch_Ymax = IdxTouch_Ymax((b ~= 1).*IdxTouch_Ymax > 1);

IdxTouch_Ymin = find( (Y-BallBorderDist) <= Ymin);
b = [0, diff(IdxTouch_Ymin)];
IdxTouch_Ymin = IdxTouch_Ymin((b ~= 1).*IdxTouch_Ymin > 1);

IdxTouch = sort([IdxTouch_Xmax, IdxTouch_Xmin, IdxTouch_Ymax, IdxTouch_Ymin]);

end

% fonction qui classe les boules dans l'odre de leur premier mouvement et qui renvoi aussi le nombres de boules qui ont bougé pendant la partie
% On commence par verifier si la boule a bouger et donc su FirstMoveIdx vaut la longueur du vecteur + 1 comme definit dans GetFirstMoveIdx
% nous cherchons donc ensuite a evaluer tout les cas possibles en commencant par chercher la plus petite de FirstMoveIdx et donc de l'appeler Firstball 
% Nous analysons ensuite la longueur de ce vecteur pour que si elle vaut 2 ou trois on comare les MoveDistPx et donc de savoir laquelle est la vrai premiere. 
% une fois que la firstball est definit, on fait de meme mais avec la plus grande Valeur de FirstMoveIdx pour definir la troisieme boules et on prossede a la meme methode que pour firstball. 
% enfin lorsque nous avons first et lastball, la deuxieme est celle qui manque et que l'on peut trouver avec la fct setdiff qui compore [lastball first ball] avec [1 2 3]

function [FirstBall,SecondBall,LastBall, NbBallsMoved] = GetBallMoveOrder(Xr, Yr, Xy, Yy, Xw, Yw, MoveDistPx) 

a = 3;

[FirstMoveIdxr, MoveDistr] = GetFirstMoveIdx(Xr,Yr, MoveDistPx);
if FirstMoveIdxr == length(Xr)+1
    a = a-1;
end
[FirstMoveIdxy, MoveDisty] = GetFirstMoveIdx(Xy,Yy, MoveDistPx);
if FirstMoveIdxy == length(Xy)+1
    a = a-1;
end
[FirstMoveIdxw, MoveDistw] = GetFirstMoveIdx(Xw,Yw, MoveDistPx);
if FirstMoveIdxw == length(Xw)+1
    a = a-1;
end

NbBallsMoved = a;

FirstMoveIdx = [FirstMoveIdxr, FirstMoveIdxy, FirstMoveIdxw];
MoveDist = [MoveDistr, MoveDisty, MoveDistw];

FirstBall = find(FirstMoveIdx == min(FirstMoveIdx));

if length(FirstBall) == 1
    LastBall = find(FirstMoveIdx == max(FirstMoveIdx));
    if length(LastBall) == 2
        LastBall = find(MoveDist == min(MoveDist(LastBall(1)), MoveDist(LastBall(2))));
    end 
end 

if length(FirstBall) == 2
    FirstBall = find(MoveDist == max(MoveDist(FirstBall(1)), MoveDist(FirstBall(2))));
    LastBall = find(FirstMoveIdx == max(FirstMoveIdx));
end

if length(FirstBall) == 3
    FirstBall = find(MoveDist == max(MoveDist));
    LastBall = find(MoveDist == min(MoveDist));
end

SecondBall = setdiff([1 2 3], [FirstBall LastBall]);

end

% fonction qui change les valeurs Nan en la prochaines valeur valide.
% Pour cela on utilise la fonction interp1.
% On fait attention au cas ou la première valeur est un Nan car il n'est pas traité par interp1.

function [X,Y]=InterpolateNan(X,Y)

ll = find(~isnan(X));
kk = find(~isnan(Y));
nn = find(isnan(X));
mm = find(isnan(Y));

nX = interp1([0 ll],X([1 ll]),nn,'next');
nY = interp1([0 kk],Y([1 kk]),mm,'next');

X(nn) = nX;
Y(mm) = nY;

if isnan(X(1))
    X(1)= X(2);
end
if isnan(Y(1))
    Y(1)= Y(2);
end

end

% fonction qui remplace les valeurs abérrantes par la valeur précendente.
% Pour cela on utilise la fonction isoutlier avec la méthode movmedian.
% Nous avons bien verifier que le outlier est bien en X et en Y.

function [X,Y]=RemoveOutlier(X,Y)

ix = find(isoutlier(X,'movmedian',10));
iy = find(isoutlier(Y,'movmedian',10));

idx = intersect(ix, iy);

if (isempty(idx) ~=1)

    if (idx(1) == 1)
        idx=idx(2:end);
    end

    X(idx)=X(idx-1);
    Y(idx)=Y(idx-1);
end

end 

